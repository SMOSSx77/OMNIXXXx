package com.omnix.app

import android.Manifest
import android.app.*
import android.appwidget.AppWidgetManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.app.usage.UsageStatsManager
import android.view.Gravity
import android.view.View
import android.widget.*
import android.hardware.camera2.CameraManager
import com.google.zxing.integration.android.IntentIntegrator
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("omnix", MODE_PRIVATE) }
    private var theme = "Violet"
    private var torchOn = false
    private val handler = Handler(Looper.getMainLooper())
    private val themes = linkedMapOf(
        "Violet" to intArrayOf(0xff090914.toInt(), 0xff211a38.toInt(), 0xffb69cff.toInt(), 0xffe8e2fa.toInt()),
        "AMOLED" to intArrayOf(Color.BLACK, 0xff171717.toInt(), 0xffeeeeee.toInt(), 0xffbbbbbb.toInt()),
        "Ice" to intArrayOf(0xff071521.toInt(), 0xff102b3d.toInt(), 0xff67e8f9.toInt(), 0xffe0f7fa.toInt()),
        "Red" to intArrayOf(0xff19090e.toInt(), 0xff391722.toInt(), 0xffff8b9a.toInt(), 0xffffe4e8.toInt()),
        "Green" to intArrayOf(0xff071811.toInt(), 0xff143326.toInt(), 0xff6ee7b7.toInt(), 0xffd1fae5.toInt()),
        "Light" to intArrayOf(0xffedf0f7.toInt(), Color.WHITE, 0xff7452c8.toInt(), 0xff252336.toInt())
    )
    private val refresh = object : Runnable { override fun run() { if (::content.isInitialized && content.tag == "dashboard") showDashboard(); handler.postDelayed(this, 5000) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        theme = prefs.getString("theme", "Violet") ?: "Violet"
        buildShell(); showDashboard(); handler.postDelayed(refresh, 5000)
    }
    override fun onDestroy() { handler.removeCallbacks(refresh); super.onDestroy() }

    private fun palette():IntArray { val p=(themes[theme] ?: themes.getValue("Violet")).copyOf(); if(theme=="Custom") p[2]=prefs.getInt("customAccent",0xffb69cff.toInt()); return p }
    private fun muted() = if (theme == "Light") 0xff626174.toInt() else 0xffc7c1d8.toInt()
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { this.text=text; textSize=size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun rounded(color: Int): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = 22f; setStroke(1, if (theme == "Light") 0xffdedbea.toInt() else 0x33ffffff) }
    private fun buildShell() {
        val p=palette()
        root=LinearLayout(this).apply { orientation=1; setBackgroundColor(p[0]) }
        val header=LinearLayout(this).apply { orientation=1; setPadding(22,20,22,14) }
        header.addView(label("OMNIX",28f,p[2],true))
        header.addView(label("DEVICE CONTROL CENTER  •  1.1",10f,muted()))
        root.addView(header)
        val scroll=ScrollView(this)
        content=LinearLayout(this).apply { orientation=1; setPadding(16,4,16,18) }
        scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { gravity=Gravity.CENTER; setPadding(5,8,5,8); setBackgroundColor(p[1]) }
        listOf("Ana sayfa","Cihaz","Araçlar","Ayarlar").forEach { name ->
            val b=TextView(this).apply { text=name; textSize=12f; gravity=Gravity.CENTER; setTextColor(p[2]); setPadding(3,12,3,12); setOnClickListener { when(name){"Ana sayfa"->showDashboard();"Cihaz"->showDevice();"Araçlar"->showTools();else->showSettings()} } }
            nav.addView(b,LinearLayout.LayoutParams(0,-2,1f))
        }
        root.addView(nav); setContentView(root)
        val duration=prefs.getInt("introDuration",450).toLong()
        when(prefs.getString("introAnim","Fade")) {
            "Slide" -> { root.alpha=0f; root.translationY=18f; root.animate().alpha(1f).translationY(0f).setDuration(duration).start() }
            "Zoom" -> { root.alpha=0f; root.scaleX=0.97f; root.scaleY=0.97f; root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(duration).start() }
            else -> { root.alpha=0f; root.animate().alpha(1f).setDuration(duration).start() }
        }
    }
    private fun section(t:String){ content.addView(label(t,16f,palette()[2],true).apply{setPadding(2,17,2,8)}) }
    private fun card(title:String,value:String,detail:String="") {
        val p=palette(); val box=LinearLayout(this).apply{orientation=1;setPadding(16,14,16,14);background=rounded(p[1])}
        box.addView(label(title.uppercase(Locale.getDefault()),10f,muted(),true))
        box.addView(label(value,21f,p[2],true).apply{setPadding(0,5,0,2)})
        if(detail.isNotBlank()) box.addView(label(detail,11f,muted()))
        val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,7);content.addView(box,lp)
    }
    private fun action(text:String, fn:()->Unit){ val b=TextView(this).apply{text="  $text";textSize=14f;setTextColor(palette()[3]);setPadding(16,15,12,15);background=rounded(palette()[1]);setOnClickListener{fn()}};val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,4);content.addView(b,lp) }
    private fun batteryIntent()=registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    private fun batteryLevel():Int { val i=batteryIntent();val l=i?.getIntExtra(BatteryManager.EXTRA_LEVEL,-1)?:-1;val s=i?.getIntExtra(BatteryManager.EXTRA_SCALE,-1)?:-1;return if(l>=0&&s>0) l*100/s else -1 }
    private fun batteryTemp():String {val t=batteryIntent()?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1)?:-1;return if(t>=0) "${t/10f} °C" else "Okunamıyor"}
    private fun memory():ActivityManager.MemoryInfo { val m=ActivityManager.MemoryInfo();(getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m);return m }
    private fun cpuName():String { val keys=listOf("Hardware","Processor","model name");return try{File("/proc/cpuinfo").useLines{ls->ls.firstOrNull{l->keys.any{l.startsWith(it,true)}}?.substringAfter(':')?.trim()}?:Build.HARDWARE}catch(_:Exception){Build.HARDWARE} }
    private fun cpuFreq():String { return try { val f=File("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");if(f.canRead()) "${f.readText().trim().toLong()/1000} MHz" else "Erişim kısıtlı" }catch(_:Exception){"Erişim kısıtlı"} }
    private fun thermal():String { if(Build.VERSION.SDK_INT<29)return "Android API desteklemiyor";return try{val pm=getSystemService(POWER_SERVICE) as PowerManager;when(pm.currentThermalStatus){0->"Normal";1->"Hafif";2->"Orta";3->"Ciddi";4->"Kritik";5->"Acil";6->"Kapanma seviyesi";else->"Bilinmiyor"}}catch(_:Exception){"Okunamıyor"} }
    private fun networkLabel():String { val cm=getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager;val c=cm.getNetworkCapabilities(cm.activeNetwork)?:return "Bağlantı yok";return when{c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)->"Wi-Fi";c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)->"Mobil veri";c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)->"Ethernet";else->"Bağlı"} }

    private fun showDashboard(){content.removeAllViews();content.tag="dashboard";section("CANLI SİSTEM DURUMU")
        val m=memory();val used=(m.totalMem-m.availMem)/1024/1024
        if(prefs.getBoolean("card_Pil",true)) card("Pil",if(batteryLevel()>=0)"${batteryLevel()}%" else "Okunamadı","Pil sıcaklığı ${batteryTemp()} • ${chargingState()}")
        if(prefs.getBoolean("card_RAM",true)) card("RAM","${used} MB kullanılıyor","Toplam ${m.totalMem/1024/1024} MB • Boş ${m.availMem/1024/1024} MB")
        if(prefs.getBoolean("card_İşlemci",true)) card("İşlemci",cpuName(),"${Runtime.getRuntime().availableProcessors()} çekirdek • Çekirdek 0: ${cpuFreq()}")
        if(prefs.getBoolean("card_Termal durum",true)) card("Termal durum",thermal(),"Android'in bildirdiği termal seviye. CPU/GPU sıcaklığı değildir.")
        if(prefs.getBoolean("card_Ağ",true)) card("Bağlantı",networkLabel(),"Anlık aktif ağ türü")
        if(prefs.getBoolean("card_Cihaz",true)) card("Cihaz","${Build.MANUFACTURER} ${Build.MODEL}","Android ${Build.VERSION.RELEASE} • API ${Build.VERSION.SDK_INT}")
        section("HIZLI ERİŞİM");action("Cihazın tüm teknik bilgileri"){showDevice()};action("Araç kutusunu aç"){showTools()};action("Tema, widget ve yedekleme"){showSettings()}
    }
    private fun chargingState():String {val s=batteryIntent()?.getIntExtra(BatteryManager.EXTRA_STATUS,-1)?:-1;return when(s){BatteryManager.BATTERY_STATUS_CHARGING->"Şarj oluyor";BatteryManager.BATTERY_STATUS_FULL->"Dolu";BatteryManager.BATTERY_STATUS_DISCHARGING->"Deşarj";else->"Beklemede"}}
    private fun showDevice(){content.removeAllViews();content.tag="device";section("DONANIM VE YAZILIM")
        card("Model","${Build.MANUFACTURER} ${Build.MODEL}","Ürün ${Build.PRODUCT} • Cihaz ${Build.DEVICE}")
        card("Android","${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}","Build ${Build.DISPLAY} • Güvenlik yaması ${Build.VERSION.SECURITY_PATCH}")
        card("One UI / Üretici yazılımı",System.getProperty("ro.build.version.sem")?:Build.VERSION.INCREMENTAL,"Samsung cihazlarda sürüm bilgisi üreticiye göre değişebilir")
        card("İşlemci / SoC",cpuName(),"Platform ${Build.BOARD} • Donanım ${Build.HARDWARE} • ABI ${Build.SUPPORTED_ABIS.joinToString()}")
        card("Çekirdekler","${Runtime.getRuntime().availableProcessors()}","Çekirdek 0 frekansı: ${cpuFreq()} • Tüm çekirdek frekansları üretici tarafından gizlenebilir")
        val dm=resources.displayMetrics;card("Ekran","${dm.widthPixels} × ${dm.heightPixels}","${dm.densityDpi} dpi • yoğunluk ${dm.density}")
        val st=StatFs(Environment.getDataDirectory().path);card("Dahili depolama","${st.totalBytes/1024/1024/1024} GB toplam","Kullanılan ${(st.totalBytes-st.availableBytes)/1024/1024/1024} GB • Boş ${st.availableBytes/1024/1024/1024} GB")
        val sensors=(getSystemService(SENSOR_SERVICE) as SensorManager).getSensorList(Sensor.TYPE_ALL);card("Sensörler","${sensors.size} adet",sensors.joinToString(" • "){it.name}.take(600))
        card("GPU","Sistemden doğrudan okunamıyor","GPU adı ve sürücüsü bazı Samsung yazılımlarında uygulamalara açılmaz. Tahmin gösterilmiyor.")
        card("Pil","${batteryLevel()}% • ${batteryTemp()}","Sağlık: ${batteryHealth()} • Şarj: ${chargingState()}")
        card("Termal","${thermal()}","Android termal seviyesi. Cihaz CPU/GPU sıcaklık sensörlerini açmıyorsa ayrı sıcaklık alınamaz.")
        action("Pil kullanım ayarlarını aç"){startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))}
        action("Uygulama kullanım erişimini yönet"){startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))}
    }
    private fun batteryHealth():String {val h=batteryIntent()?.getIntExtra(BatteryManager.EXTRA_HEALTH,-1)?:-1;return when(h){BatteryManager.BATTERY_HEALTH_GOOD->"İyi (yüzde değil)";BatteryManager.BATTERY_HEALTH_OVERHEAT->"Aşırı sıcak";BatteryManager.BATTERY_HEALTH_DEAD->"Arızalı";BatteryManager.BATTERY_HEALTH_COLD->"Soğuk";BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE->"Aşırı voltaj";else->"Üretici verisi yok"}}

    private fun showTools(){content.removeAllViews();content.tag="tools";section("ARAÇ KUTUSU")
        action("QR / Barkod tara"){try{IntentIntegrator(this).setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES).setPrompt("QR kodu veya barkodu çerçeveye al").setBeepEnabled(false).setOrientationLocked(false).initiateScan()}catch(e:Exception){toast("Tarayıcı açılamadı: ${e.message}")}}
        action(if(torchOn)"El fenerini kapat" else "El fenerini aç"){toggleTorch()}
        action("Pusula ve sensörler"){showSensors()}
        action("Ağ bağlantısı testi"){showNetwork()}
        action("Depolama analizi"){showStorage()}
        action("Birim dönüştürücü"){showConverter()}
        action("Kronometre"){showStopwatch()}
        action("Günlük uygulama kullanımını gör"){showUsage()}
        action("Android sistem ayarları"){startActivity(Intent(Settings.ACTION_SETTINGS))}
    }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
    private fun toggleTorch(){try{val cm=getSystemService(CAMERA_SERVICE) as CameraManager;val id=cm.cameraIdList.firstOrNull{cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)==true};if(id==null){toast("Flaş donanımı bulunamadı");return};if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.CAMERA),91);return};torchOn=!torchOn;cm.setTorchMode(id,torchOn);showTools()}catch(e:Exception){toast("El feneri kullanılamadı: ${e.message}")}}
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==91&&grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED)toggleTorch()else if(requestCode==91)toast("Kamera izni verilmedi")}

    private fun showNetwork(){val cm=getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager;val n=cm.activeNetwork;val c=cm.getNetworkCapabilities(n);val msg=buildString{append("Bağlantı: ${networkLabel()}\n");append("İnternet erişimi: ${c?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)==true}\n");append("Doğrulanmış internet: ${c?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)==true}\n");append("Ölçülü ağ: ${c?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)!=true}\n");append("Bağlantı hızı: ${c?.linkDownstreamBandwidthKbps?:0} Kbps indirme / ${c?.linkUpstreamBandwidthKbps?:0} Kbps yükleme (ağ bildirimi)")};AlertDialog.Builder(this).setTitle("Ağ analizi").setMessage(msg).setPositiveButton("Tamam",null).show()}
    private fun showStorage(){val s=StatFs(Environment.getDataDirectory().path);val total=s.totalBytes;val free=s.availableBytes;AlertDialog.Builder(this).setTitle("Depolama analizi").setMessage("Toplam: ${total/1024/1024/1024} GB\nKullanılan: ${(total-free)/1024/1024/1024} GB\nBoş: ${free/1024/1024/1024} GB\n\nBu değer Android'in veri bölümünü gösterir; üreticinin pazarlama kapasitesiyle farklı olabilir.").setPositiveButton("Tamam",null).show()}
    private fun showConverter(){val layout=LinearLayout(this).apply{orientation=1;setPadding(24,12,24,8)};val input=EditText(this).apply{hint="Değer gir";inputType=8194};val type=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,listOf("Kilometre → Mil","Mil → Kilometre","Santigrat → Fahrenheit","Fahrenheit → Santigrat","GB → MB","MB → GB"))};val output=TextView(this).apply{textSize=18f;setTextColor(palette()[2]);setPadding(0,15,0,0)};val calc=Button(this).apply{text="Hesapla";setOnClickListener{val v=input.text.toString().toDoubleOrNull();output.text=if(v==null)"Geçerli sayı gir" else when(type.selectedItemPosition){0->"${v*0.621371} mil";1->"${v/0.621371} km";2->"${v*9/5+32} °F";3->"${(v-32)*5/9} °C";4->"${v*1024} MB";else->"${v/1024} GB"}}};layout.addView(input);layout.addView(type);layout.addView(calc);layout.addView(output);AlertDialog.Builder(this).setTitle("Birim dönüştürücü").setView(layout).setPositiveButton("Kapat",null).show()}
    private fun showSensors(){val sm=getSystemService(SENSOR_SERVICE) as SensorManager;val list=sm.getSensorList(Sensor.TYPE_ALL);val names=list.joinToString("\n\n"){ "${it.name}\nÜretici: ${it.vendor} • Sürüm: ${it.version} • Güç: ${it.power} mA"};AlertDialog.Builder(this).setTitle("Sensörler (${list.size})").setMessage(names.ifBlank{"Sensör bulunamadı"}).setPositiveButton("Kapat",null).show()}
    private fun showUsage(){val us=getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager;val now=System.currentTimeMillis();val start=now-24*60*60*1000;val stats=us.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,start,now);if(stats.isNullOrEmpty()){AlertDialog.Builder(this).setTitle("Uygulama kullanımı").setMessage("Kullanım verisi yok. Önce OMNIX için kullanım erişimine izin ver.").setPositiveButton("İzin ayarları"){_,_->startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))}.show();return};val text=stats.filter{it.totalTimeInForeground>0}.sortedByDescending{it.totalTimeInForeground}.take(15).joinToString("\n"){ "${it.packageName.substringAfterLast('.')}  •  ${it.totalTimeInForeground/60000} dk"};AlertDialog.Builder(this).setTitle("Son 24 saat • En çok kullanılanlar").setMessage(text).setPositiveButton("Tamam",null).show()}
    private fun showStopwatch(){val box=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;setPadding(24,24,24,24)};val time=TextView(this).apply{text="00:00.0";textSize=36f;setTextColor(palette()[2])};var elapsed=0L;var start=0L;var running=false;val h=Handler(Looper.getMainLooper());val tick=object:Runnable{override fun run(){if(running){val t=elapsed+SystemClock.elapsedRealtime()-start;time.text=String.format(Locale.getDefault(),"%02d:%02d.%d",t/60000,(t/1000)%60,(t/100)%10);h.postDelayed(this,100)}}};val toggle=Button(this).apply{text="Başlat";setOnClickListener{if(running){elapsed+=SystemClock.elapsedRealtime()-start;running=false;text="Devam et"}else{start=SystemClock.elapsedRealtime();running=true;text="Durdur";h.post(tick)}}};val reset=Button(this).apply{text="Sıfırla";setOnClickListener{running=false;elapsed=0;time.text="00:00.0";toggle.text="Başlat"}};box.addView(time);box.addView(toggle);box.addView(reset);AlertDialog.Builder(this).setTitle("Kronometre").setView(box).setNegativeButton("Kapat"){_,_->h.removeCallbacks(tick)}.show()}

    private fun showSettings(){content.removeAllViews();content.tag="settings";section("KİŞİSELLEŞTİRME")
        action("Tema seç: $theme"){val options=themes.keys.toList()+"Özel renk seç";AlertDialog.Builder(this).setTitle("OMNIX teması").setItems(options.toTypedArray()){_,i->if(i<themes.size){theme=themes.keys.elementAt(i);prefs.edit().putString("theme",theme).apply();buildShell();showSettings()}else{val field=EditText(this).apply{hint="#B69CFF";setSingleLine(true)};AlertDialog.Builder(this).setTitle("Vurgu rengi").setMessage("HEX renk kodu gir. Örnek: #B69CFF").setView(field).setPositiveButton("Uygula"){_,_->try{val color=Color.parseColor(field.text.toString().trim());prefs.edit().putInt("customAccent",color).putString("theme","Custom").apply();theme="Custom";buildShell();showSettings()}catch(_:Exception){toast("Geçersiz HEX renk kodu")}}.setNegativeButton("İptal",null).show()}}.show()}
        action("Açılış animasyonu ve süresi"){val modes=arrayOf("Fade","Slide","Zoom");val current=prefs.getString("introAnim","Fade");AlertDialog.Builder(this).setTitle("Animasyon türü").setSingleChoiceItems(modes,modes.indexOf(current)){d,which->prefs.edit().putString("introAnim",modes[which]).apply();d.dismiss();val durations=arrayOf("250 ms","450 ms","800 ms","1200 ms");val values=intArrayOf(250,450,800,1200);AlertDialog.Builder(this).setTitle("Animasyon süresi").setItems(durations){_,i->prefs.edit().putInt("introDuration",values[i]).apply();toast("Açılış animasyonu güncellendi. Bir sonraki açılışta uygulanır.")}.show()}.setNegativeButton("İptal",null).show()}
        action("Ana ekran kartlarını özelleştir"){val items=arrayOf("Pil","RAM","İşlemci","Termal durum","Ağ","Cihaz");val checked=BooleanArray(items.size){prefs.getBoolean("card_${items[it]}",true)};AlertDialog.Builder(this).setTitle("Gösterilecek kartlar").setMultiChoiceItems(items,checked){_,which,isChecked->prefs.edit().putBoolean("card_${items[which]}",isChecked).apply()}.setPositiveButton("Kaydet"){_,_->showDashboard()}.show()}
        section("YEDEKLEME VE VERİ")
        action("JSON yedeği dışa aktar"){val json=JSONObject().put("app","OMNIX").put("version","1.1.0").put("theme",theme).put("customAccent",prefs.getInt("customAccent",0xffb69cff.toInt())).put("createdAt",SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(Date())).put("preferences",JSONObject().apply{listOf("Pil","RAM","İşlemci","Termal durum","Ağ","Cihaz").forEach{put("card_$it",prefs.getBoolean("card_$it",true))}});val i=Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,"omnix-backup.json");pendingBackup=json.toString(2);startActivityForResult(i,601)}
        action("JSON yedeğini içe aktar"){val i=Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json");startActivityForResult(i,602)}
        action("Ana ekrana OMNIX widget ekleme"){AlertDialog.Builder(this).setTitle("OMNIX widget").setMessage("Ana ekranda boş bir alana basılı tut → Widget'lar → OMNIX. Widget pil ve RAM durumunu gösterir.").setPositiveButton("Tamam",null).show()}
        section("BİLGİ")
        card("Uygulama","OMNIX 1.1.0","Android cihaz kontrol merkezi")
        card("Veri doğruluğu","Gerçek sistem API'leri","CPU/GPU sıcaklığı, GPU modeli ve pil sağlığı yüzdesi cihaz yazılımı erişimi vermiyorsa gösterilmez. Pil sıcaklığı CPU sıcaklığı değildir.")
    }
    private var pendingBackup:String?=null
    private fun applyBackup(uri:Uri){try{val j=JSONObject(contentResolver.openInputStream(uri)!!.bufferedReader().use{it.readText()});if(j.optString("app")!="OMNIX")throw Exception("Bu dosya OMNIX yedeği değil");val e=prefs.edit();val t=j.optString("theme","Violet");if(themes.containsKey(t)||t=="Custom"){theme=t;e.putString("theme",t)};if(j.has("customAccent"))e.putInt("customAccent",j.optInt("customAccent",0xffb69cff.toInt()));val p=j.optJSONObject("preferences");if(p!=null){val keys=p.keys();while(keys.hasNext()){val k=keys.next();e.putBoolean(k,p.optBoolean(k,true))}};e.apply();buildShell();showSettings();toast("Yedek geri yüklendi")}catch(e:Exception){toast("Yedek açılamadı: ${e.message}")}}
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==601&&resultCode==RESULT_OK&&data?.data!=null){try{contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use{it.write(pendingBackup?:"{}")} ;toast("JSON yedeği kaydedildi")}catch(e:Exception){toast("Yedek kaydedilemedi: ${e.message}")};pendingBackup=null;return};if(requestCode==602&&resultCode==RESULT_OK&&data?.data!=null){applyBackup(data.data!!);return};val result=IntentIntegrator.parseActivityResult(requestCode,resultCode,data);if(result!=null){if(result.contents!=null)AlertDialog.Builder(this).setTitle("Tarama sonucu").setMessage(result.contents).setPositiveButton("Kopyala"){_,_->(getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("OMNIX QR",result.contents));toast("Panoya kopyalandı")}.setNegativeButton("Kapat",null).show()else toast("Tarama iptal edildi")}}
}

class OmnixWidget : android.appwidget.AppWidgetProvider() {
    override fun onUpdate(context:Context, manager:AppWidgetManager, ids:IntArray){ids.forEach{id->val i=context.registerReceiver(null,IntentFilter(Intent.ACTION_BATTERY_CHANGED));val l=i?.getIntExtra(BatteryManager.EXTRA_LEVEL,-1)?:-1;val s=i?.getIntExtra(BatteryManager.EXTRA_SCALE,-1)?:-1;val pct=if(l>=0&&s>0)l*100/s else -1;val m=ActivityManager.MemoryInfo();(context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(m);val used=(m.totalMem-m.availMem)/1024/1024;val v=android.widget.RemoteViews(context.packageName,R.layout.omnix_widget);v.setTextViewText(R.id.widget_title,"OMNIX  •  ${if(pct>=0)"$pct% pil" else "Pil ?"}");v.setTextViewText(R.id.widget_detail,"RAM ${used} / ${m.totalMem/1024/1024} MB");manager.updateAppWidget(id,v)}}
}
