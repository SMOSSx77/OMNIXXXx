# OMNIX Android

OMNIX is a native Android device dashboard and utility toolbox. This source project targets Android 8.0+ (minSdk 26) and compiles against Android 15 (API 35).

## Included in this source revision

- Live dashboard: battery percentage and battery temperature, charge state, RAM, CPU identification/frequency where readable, Android thermal status, active network type.
- Device report: build/device identifiers, Android release/security patch, ABI, display metrics, storage partition usage, available sensors, battery health state.
- Utility tools: QR/barcode scanning (ZXing), flashlight, sensor list, network capability check, storage report, unit converter, stopwatch, app-usage summary (requires Usage Access permission).
- Appearance: Violet, AMOLED, Ice, Red, Green, Light and custom HEX accent themes.
- Dashboard card visibility preferences.
- JSON backup export/import using Android's document picker.
- Home-screen widget showing battery and RAM.
- Configurable fade/slide/zoom opening animation and duration.
- GitHub Actions workflow to build and upload a debug APK artifact.

## Important hardware limitations

Android does not expose every sensor to third-party apps. This app reports the battery temperature sensor and Android's thermal status separately. It does not mislabel battery temperature as CPU/GPU temperature. GPU model, per-core frequencies, CPU/GPU temperatures and battery-health percentage may be blocked by the device firmware. When unavailable, OMNIX says so instead of inventing a value.

The RAM and storage numbers are Android-reported system values. Network information reports the active network and Android's advertised link bandwidth, not a measured internet speed test.

## Build on GitHub (phone-only workflow)

1. Extract this ZIP.
2. Upload the **contents of the `OMNIX` folder** to the root of your GitHub repository (so `settings.gradle`, `build.gradle`, `app/` and `.github/` are at repository root).
3. Commit to `main` or `master`, or open Actions and run **Build OMNIX APK** manually.
4. When the workflow finishes successfully, open its run, scroll to **Artifacts**, and download `OMNIX-debug-apk`.
5. Extract the artifact ZIP and install `app-debug.apk` on the phone. Android may ask permission to install from that source.

## Build versions

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK Platform 35

This package is source code, not a prebuilt APK. The build must be run in GitHub Actions to confirm the APK. The workflow is configured to fail if the APK is not produced.
